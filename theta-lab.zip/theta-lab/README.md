# ⏳ Theta Lab — a systematic option-selling backtester

An interactive Streamlit dashboard that answers one empirical question
honestly: **did systematically selling option premium actually make money,
and what did the tail look like when it didn't?**

Pick an underlying (SPY, QQQ, NIFTY 50, GLD, or any Yahoo ticker), a
short-premium structure (short put, straddle, strangle, iron condor,
covered call), your entry/exit rules and your cost assumptions — and get a
full mark-to-market equity curve, a trade-by-trade PnL distribution, and a
direct view of the volatility risk premium (implied vol sold vs realised
vol delivered) over a decade of data.

## The core idea

Option sellers are paid implied volatility and pay out realised volatility.
Historically, index implied vol has tended to sit above subsequently
delivered vol — the *volatility risk premium* — but harvesting it means
accepting rare, violent losses (short-vol PnL is negatively skewed:
many small wins, occasional large losses). This tool makes that trade-off
visible instead of asserting it.

## How premiums are modelled (the honest part)

Free historical option chains don't exist, so **every option price in this
backtest is synthesised with Black–Scholes**:

- **Volatility input** — either a listed vol index (VIX for SPY, VXN for
  QQQ, India VIX for NIFTY, GVZ for GLD), or trailing realised vol × a
  user-set markup, so you can stress how rich premiums need to be.
- **Marks** — positions are repriced daily with that day's vol; expiry
  settles at exact intrinsic value.
- **Rates/dividends** — user-set continuous r and q.

This is the biggest assumption in the tool, which is why it is a visible
input rather than a buried constant, and why there is a cost-sensitivity
stress chart.

## Mechanics

| Piece | Implementation |
|---|---|
| Entry | Event-driven: open a new position whenever flat (optional cooldown). Strikes by target delta (closed-form inversion) or % OTM. |
| Exits | Hold to expiry, profit target (default 50% of credit), stop loss (default 2× credit), evaluated on daily closes. |
| Sizing | Notional (spot × 100 × contracts) = chosen % of current equity; roughly cash-secured, no margin or leverage modelled. |
| Accounting | Equity = cash + MTM of open positions every day. Account is flat between trades, so per-trade PnL is exact and the trade log reconciles with the equity curve to the cent (verified in tests). |
| Costs | Commission per contract per leg per side + slippage as % of premium per side. |
| Offline mode | A built-in synthetic market (GBM + mean-reverting stochastic vol with a leverage effect, vol index quoted at a premium) powers a demo when live data is unreachable and gives the tests a deterministic fixture. |

## Running it

```bash
pip install -r requirements.txt
streamlit run app.py          # opens at http://localhost:8501
python smoke_test.py          # 30 checks: pricing maths + engine accounting
```

## Project layout

```
app.py          Streamlit UI + caching; no maths lives here
backtest.py     Event-driven engine, position accounting, trade log
pricing.py      Black–Scholes, deltas, strike-from-delta, vol estimators
                (NumPy only — normal CDF/PPF implemented and unit-tested)
data_loader.py  yfinance access + synthetic offline market
metrics.py      Performance & trade statistics
plots.py        All Plotly figures, one shared dark theme
smoke_test.py   Reference-value and accounting-identity tests
```

## Known limitations (worth saying out loud)

- **Flat vol surface** — one vol number per day, no skew/smile. Real short
  puts collect more (and risk more) than this model shows.
- European exercise, daily closes only: no intraday stop-outs or early
  assignment.
- Vol indices are ~30-day measures applied to all DTEs.
- Continuous strikes (real chains are gridded); no margin model.

## Extensions

Skew via a risk-reversal adjustment · a delta-hedged variant to isolate
the vol premium · weekly expiries · margin/buying-power modelling.

---

*Educational project — synthetic premiums, not investment advice.*
